
CREATE DATABASE `company`;
USE `company` ;

CREATE  TABLE `cliente` (
  `id_cliente` INT NOT NULL AUTO_INCREMENT ,
  `nombre` VARCHAR(45) NULL ,
  `apellido` VARCHAR(45) NULL ,
  PRIMARY KEY (`id_cliente`) )
ENGINE = InnoDB;

CREATE  TABLE `factura` (
  `id_factura` INT NOT NULL AUTO_INCREMENT ,
  `fecha` DATE NULL ,
  `importe` DECIMAL(7,2) NULL ,
  `cliente_id_cliente` INT NOT NULL ,
  PRIMARY KEY (`id_factura`) ,
  INDEX `fk_factura_cliente1_idx` (`cliente_id_cliente` ASC) ,
  CONSTRAINT `fk_factura_cliente1`
    FOREIGN KEY (`cliente_id_cliente` )
    REFERENCES `company`.`cliente` (`id_cliente` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

CREATE  TABLE `detalle` (
  `iddetalle` INT NOT NULL AUTO_INCREMENT ,
  `factura_id_factura` INT NOT NULL ,
  PRIMARY KEY (`iddetalle`) ,
  INDEX `fk_detalle_factura1_idx` (`factura_id_factura` ASC) ,
  CONSTRAINT `fk_detalle_factura1`
    FOREIGN KEY (`factura_id_factura` )
    REFERENCES `company`.`factura` (`id_factura` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

CREATE  TABLE `articulo` (
  `idarticulo` INT NOT NULL AUTO_INCREMENT ,
  `descripcion` VARCHAR(800) NULL ,
  `pvp` DECIMAL(6,2) NULL ,
  PRIMARY KEY (`idarticulo`) )
ENGINE = InnoDB;

CREATE  TABLE `detalle_has_articulo` (
  `detalle_iddetalle` INT NOT NULL ,
  `articulo_idarticulo` INT NOT NULL ,
  `cantidad` INT NULL ,
  PRIMARY KEY (`detalle_iddetalle`, `articulo_idarticulo`) ,
  INDEX `fk_detalle_has_articulo_articulo1_idx` (`articulo_idarticulo` ASC) ,
  INDEX `fk_detalle_has_articulo_detalle_idx` (`detalle_iddetalle` ASC) ,
  CONSTRAINT `fk_detalle_has_articulo_detalle`
    FOREIGN KEY (`detalle_iddetalle` )
    REFERENCES `company`.`detalle` (`iddetalle` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_detalle_has_articulo_articulo1`
    FOREIGN KEY (`articulo_idarticulo` )
    REFERENCES `company`.`articulo` (`idarticulo` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

