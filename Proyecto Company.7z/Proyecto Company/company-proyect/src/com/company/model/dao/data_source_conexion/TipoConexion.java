package com.company.model.dao.data_source_conexion;

public enum TipoConexion {
	SQLSERVER,
	MYSQL,
	ORACLE	
}
