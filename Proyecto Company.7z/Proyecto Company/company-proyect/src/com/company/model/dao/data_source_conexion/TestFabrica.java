package com.company.model.dao.data_source_conexion;

public class TestFabrica {
	//Datos de la Base de Datos
	 private static String usuario = "root";
	 private static String pwd = "";
	 private static String bd = "datos_company";
	 private static Conexion miConexion;
	
	public static void main(String[] args) {
		FactoryDataSource miFabrica;
		miFabrica = new FactoryDataSource(TipoConexion.MYSQL);
		miConexion = miFabrica.createConexion(bd, usuario, pwd);
		System.out.println("Est� conectado con: " +
		                    miConexion.descripcion());
	}
}
