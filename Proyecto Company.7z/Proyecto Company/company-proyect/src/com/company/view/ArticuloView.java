package com.company.view;
/*
 * Autor: Ezequiel Llarena Borges
 * Fecha: 22/11/2019
 * Descripci�n: 
 */
public class ArticuloView {  
	public void imprimirDatosArticulo(int id,String nombre, double apellido) {
		System.out.println("**** DATOS Articulo ****");   
		System.out.println("Id: "+id);   
		System.out.println("Nombre: "+nombre);   
		System.out.println("Apellido: "+apellido);  
	} 
}