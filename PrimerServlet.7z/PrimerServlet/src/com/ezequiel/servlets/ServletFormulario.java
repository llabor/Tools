package com.ezequiel.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ServletFormulario
 */

// La siguiente anotaci�n registra el servlet para todas las peticiones al servidor con la 
// sintaxis http://localhost:8080/PrimerServlet/ServletFormulario
/*@WebServlet("/ServletFormulario")*/
public class ServletFormulario extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public ServletFormulario() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();

        out.println("<html>");
        out.println("<head></head>");         
        out.println("<body>");

        out.println("Usuario:");
        String usu = request.getParameter("usuario");
        out.println(usu);
        out.println("<br>");
        out.println("Clave:");         
        String cla = request.getParameter("clave");
        out.println(cla);
        
        out.println("</body>");
        out.println("</html>");  
	}

}
