package com.persistencia_jpa.eclipselink.persistencia_jpa_eclipselink;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
